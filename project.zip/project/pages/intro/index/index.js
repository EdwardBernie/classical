(function($) {
    $('.dateTime').chosen({
        disable_search: true
    }).change(function(event, opt) { //回调函数
        // var $sel = $(this).find("option:selected");
        // selectGet($sel.val());
        // console.log(opt);
    }).trigger("change");
}(jQuery))
