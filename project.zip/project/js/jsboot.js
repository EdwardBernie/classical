﻿SrcBoot.output((function() {
    var arr = [];

    arr.push('js/lib/jquery/' + (document.addEventListener ? 'jquery-2.2.3.min.js' : 'jquery-1.11.0.min.js'));

    // 对JSON API进行支持
    if (!JSON.stringify) {
        arr.push('js/lib/json3.min.js');
    }

    arr = arr.concat([
        'js/lib/mustache.js',
        'js/common.js'
    ]);

    // 非调试阶段去掉mockjs支持
    if (SrcBoot.debug) {
        // arr.push('http://218.4.136.118:8086/rap.plugin.js?projectId=49');
        // arr.push('js/lib/mock-min.js');
    }

    return arr;
}()));
