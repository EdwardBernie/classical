(function($) {
    var $sidebar = $('#side'),
        $back = $('#goback',$sidebar);

    $back.on('click', function() {
        $('body,html').animate({
            scrollTop: 0
        }, 300);
    });

    $(window).scroll(function() {
        var offTop = $(window).scrollTop();
        if (offTop > 200) {
            $sidebar.addClass('active');
        } else {
            $sidebar.removeClass('active');
        }
    });
}(jQuery));
